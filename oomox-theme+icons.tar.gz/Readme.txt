Generate theme in OS8.0 oomox

Video tutorial https://radikal.ru/video/DdTdTtagD0E

Example oomox_griggorii_source_my_presets_color copy no pastehome directory 

/.config/oomox/colors

generate icons automate home directory .icons
--------------------------------------------------------------------------------------------------------------------
donate and support youtube like

suppot like https://www.youtube.com/watch?v=PXkMqNjOLZo

and donate many https://money.yandex.ru/to/410014999913799

tfanks Griggorii@gmail.com

